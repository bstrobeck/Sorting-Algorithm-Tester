//Brandtly Strobeck Data Structures Assignment 2
//NOTE TO GRADER: If you run this on your machine, then you must have a folder on your C drive called SortResults... I couldn't figure out a safer place to put the sort_results.txt file, and still find it easily

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.util.Arrays;

public class SortTester 
{
	public static void main(String[] args)
	{
		
		int[] listSizes = {500,1000,5000,10000};//,1000,5000,10000}; add back later, want to make it work for 500 size first
		long time = 0;
		LinkedList originalAscending = null;//Initialize each list outside of loop so that they can be used outside of loop
		LinkedList originalDescending = null;
		LinkedList originalRandom = null;
		for(int i = 0; i < listSizes.length; i++)//first loop through, it will do all the 500 lists, then the 1000, etc. which means output has to be captured at the end of for loop, before it increments
		{
	//master lists that we'll use to clone for each sorting routine to operate on the same set of data, for scientific method's sake
			 originalAscending = LinkedList.buildAscending(listSizes[i]);
			 originalDescending = LinkedList.buildDescending(listSizes[i]);
			 originalRandom = LinkedList.buildRandom(listSizes[i]);
	//create bubble lists. Need one list to test time, and another list to test counters.
			 LinkedList bubbleAscending1 = (LinkedList) originalAscending.clone();
			 LinkedList bubbleAscending2 = (LinkedList) originalAscending.clone();
			 LinkedList bubbleDescending1 = (LinkedList) originalDescending.clone();
			 LinkedList bubbleDescending2 = (LinkedList) originalDescending.clone();
			 LinkedList bubbleRandom1 = (LinkedList) originalRandom.clone();
			 LinkedList bubbleRandom2 = (LinkedList) originalRandom.clone();
	//test bubble ascending
			 //time = resetTime(time);
			 time = bubbleAscending1.bubbleSortTime();//for streamlines sake, run the time test, then the counting test
			 Object[][] ara = bubbleAscending2.bubbleSortCounter("Ascending " + listSizes[i], time); 
			 writeFile(ara);
	//test bubble descending
			 time = resetTime(time);
			 time = bubbleDescending1.bubbleSortTime();
			 ara = bubbleDescending2.bubbleSortCounter("Descending " + listSizes[i], time);
			 writeFile(ara);
	//test bubble random
			 time = resetTime(time);
			 time = bubbleRandom1.bubbleSortTime();
			 ara = bubbleRandom2.bubbleSortCounter("Random " + listSizes[i], time);
			 writeFile(ara);
	//create selection lists
			 LinkedList selectionAscending1 = (LinkedList) originalAscending.clone();
			 LinkedList selectionAscending2 = (LinkedList) originalAscending.clone();
			 LinkedList selectionDescending1 = (LinkedList) originalDescending.clone();
			 LinkedList selectionDescending2 = (LinkedList) originalDescending.clone();
			 LinkedList selectionRandom1 = (LinkedList) originalRandom.clone();
			 LinkedList selectionRandom2 = (LinkedList) originalRandom.clone();
	//test selection ascending
			 time = resetTime(time);
			 time = selectionAscending1.selectionSortTime();
			 ara = selectionAscending2.selectionSortCounter("Ascending " + listSizes[i], time);
			 writeFile(ara);
	//test selection descending
			 time = resetTime(time);
			 time = selectionDescending1.selectionSortTime();
			 ara = selectionDescending2.selectionSortCounter("Descending " + listSizes[i], time);
			 writeFile(ara);
	//test selection random
			 time = resetTime(time);
			 time = selectionRandom1.selectionSortTime();
			 ara = selectionRandom2.selectionSortCounter("Random " + listSizes[i], time);
			 writeFile(ara);
	//create insertion lists
			 LinkedList insertionAscending1 = (LinkedList) originalAscending.clone();
			 LinkedList insertionAscending2 = (LinkedList) originalAscending.clone();
			 LinkedList insertionDescending1 = (LinkedList) originalDescending.clone();
			 LinkedList insertionDescending2 = (LinkedList) originalDescending.clone();
			 LinkedList insertionRandom1 = (LinkedList) originalRandom.clone();
			 LinkedList insertionRandom2 = (LinkedList) originalRandom.clone();
	//test insertion ascending
			 time = resetTime(time);
			 time = insertionAscending1.insertionSortTime();
			 ara = insertionAscending2.insertionSortCounters("Ascending " + listSizes[i], time);
			 writeFile(ara);
	//test insertion descending
			 time = resetTime(time);
			 time = insertionDescending1.insertionSortTime();
			 ara = insertionDescending2.insertionSortCounters("Descending " + listSizes[i], time);
			 writeFile(ara);
	//test insertion random
			 time = resetTime(time);
			 time = insertionRandom1.insertionSortTime();
			 ara = insertionRandom2.insertionSortCounters("Random " + listSizes[i], time);
			 writeFile(ara);	 
	//create insertion cut/paste lists
			 LinkedList insertionCutPasteAscending1 = (LinkedList) originalAscending.clone();
			 LinkedList insertionCutPasteAscending2 = (LinkedList) originalAscending.clone();
			 LinkedList insertionCutPasteDescending1 = (LinkedList) originalDescending.clone();
			 LinkedList insertionCutPasteDescending2 = (LinkedList) originalDescending.clone();
			 LinkedList insertionCutPasteRandom1 = (LinkedList) originalRandom.clone();
			 LinkedList insertionCutPasteRandom2 = (LinkedList) originalRandom.clone();
	//test  insertion cut/paste ascending
			 time = resetTime(time);
			 time = insertionCutPasteAscending1.insertionSortCutPasteTime();
			 ara = insertionCutPasteAscending2.insertionSortCutPasteCounter("Ascending " + listSizes[i], time);
			 writeFile(ara);
	//test insertion cut/paste descending
			 time = resetTime(time);
			 time = insertionCutPasteDescending1.insertionSortCutPasteTime();
			 ara = insertionCutPasteDescending2.insertionSortCutPasteCounter("Descending " + listSizes[i], time);
			 writeFile(ara);
	//test insertion c/p random
			 time = resetTime(time);
			 time = insertionCutPasteRandom1.insertionSortCutPasteTime();
			 ara = insertionCutPasteRandom2.insertionSortCutPasteCounter("Random " + listSizes[i], time);
			 writeFile(ara);	 
		}
	}
	
	public static boolean writeFile(Object[][] array)
	{
		FileWriter fw = null;
		BufferedWriter bw = null;
		try
		{
			
			File file = new File("C:/SortResults/sort_results.txt");//there needs to be a folder on C drive called SortResults for this to execute properly
			if(!file.exists())
			{
				file.createNewFile();
			}
			 fw = new FileWriter(file.getAbsolutePath(),true);
			 bw = new BufferedWriter(fw);
			
			for(int i = 0; i < array.length; i++)
			{
				for(int j = 0; j < array[i].length; j++)
				{
					bw.write(array[i][j]+ " ");
				}
				bw.newLine();
				
			}
			bw.newLine();
			bw.flush();
			return true;
		}
		catch(IOException e)
		{
			e.printStackTrace();
			return false;
		}
		finally
		{
			try 
			{
				if(bw != null)
					bw.close();
				
				if(fw != null)
					fw.close();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		
	}//end writeFile
	private static long resetTime(long time)
	{
		return time = 0;
	}
}
